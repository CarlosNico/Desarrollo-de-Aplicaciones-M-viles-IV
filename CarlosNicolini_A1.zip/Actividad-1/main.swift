import Foundation

struct Articulo {
    let nombre: String
    let precio: Int
    var stock: Int     

    mutating func reducirStock(por cantidad: Int) {
        stock -= cantidad
    }
}

enum OpcionMenu: String {
    case comprar = "1"
    case salir = "2"
    case desconocida

    init(input: String) {
        self = OpcionMenu(rawValue: input) ?? .desconocida
    }
}
// -----INVENTARIO-----

var inventario: [Int: Articulo] = [
    1: Articulo(nombre: "Zapatos", precio: 500, stock: 10),
    2: Articulo(nombre: "Playeras", precio: 400, stock: 40),
    3: Articulo(nombre: "Sombrero", precio: 140, stock: 5),
    4: Articulo(nombre: "Pantallas", precio: 3500, stock: 10)
]

func col(_ text: String, width: Int) -> String {
    if text.count >= width {
        return String(text.prefix(width))
    } else {
        return text.padding(toLength: width, withPad: " ", startingAt: 0)
    }
}

// ------Mostrar el inventario------

func mostrarInventario() {
    print("\n╔════════════════════════════════════════════════════════════╗")
    print("║                       ARTÍCULOS DISPONIBLES                ║")
    print("╚════════════════════════════════════════════════════════════╝")

    print("┌─────┬────────────────────┬────────────┬────────┐")
    print("│ ID  │ ARTÍCULO           │ PRECIO     │ STOCK  │")
    print("├─────┼────────────────────┼────────────┼────────┤")

    for (id, articulo) in inventario.sorted(by: { $0.key < $1.key }) {
        let idStr = col("\(id)", width: 4)
        let nombreStr = col(articulo.nombre, width: 20)
        let precioStr = col("$\(articulo.precio)", width: 10)
        let stockStr = col("\(articulo.stock)", width: 6)

        print("│ \(idStr)│\(nombreStr)│\(precioStr)  │ \(stockStr) │")
    }

    print("└─────┴────────────────────┴────────────┴────────┘")
}

func leerInt(mensaje: String) -> Int? {
    print(mensaje, terminator: "")
    guard let input = readLine(), let numero = Int(input), numero > 0 else {
        return nil
    }
    return numero
}

// Bucle del menu principal del sistema
while true {
    print("\n╔════════════════════════════════════════════════════════════╗")
    print("║                     BIENVENIDOS A COPPEL                   ║")
    print("╠════════════════════════════════════════════════════════════╣")
    print("║                  Sistema de Punto de Venta v1.5            ║")
    print("╚════════════════════════════════════════════════════════════╝\n")

    mostrarInventario()

    print("\n┌────────────────────────── MENÚ PRINCIPAL ──────────────────────────┐")
    print("│ [1]  Comprar artículo                                              │")
    print("│ [2]  Salir del sistema                                             │")
    print("└────────────────────────────────────────────────────────────────────┘")
    print("Seleccione una opción: ", terminator: "")

    guard let opcionStr = readLine() else { continue }
    let opcion = OpcionMenu(input: opcionStr)

    switch opcion {

    case .comprar:
        guard let numArticulo = leerInt(mensaje: "\n Ingresa el NÚMERO del artículo: "),
              var articulo = inventario[numArticulo] else {
            print("\n Artículo no válido.")
            continue
        }

        guard let cantidad = leerInt(mensaje: " Cantidad (Stock: \(articulo.stock)): ") else {
            print("\n Cantidad no válida.")
            continue
        }

        if cantidad > articulo.stock {
            print("\n Solo quedan \(articulo.stock) unidades de \(articulo.nombre).")
        } else {
            let total = cantidad * articulo.precio

            print("\n╔═══════════════════════════════════════════════════╗")
            print("║                ¡COMPRA EXITOSA!                   ║")
            print("╠═══════════════════════════════════════════════════╣")
            print(" Artículo : \(articulo.nombre)")
            print(" Cantidad : \(cantidad)")
            print(" Total    : $\(total)")
            print("╚═══════════════════════════════════════════════════╝")

            articulo.reducirStock(por: cantidad)
            inventario[numArticulo] = articulo
        }

    case .salir:
        print("\n╔═══════════════════════════════════════════════════╗")
        print("║   Gracias por preferir a Coppel. ¡Hasta luego!    ║")
        print("╚═══════════════════════════════════════════════════╝\n")
        exit(0)

    case .desconocida:
        print("\n Opción inválida. Solo puedes elegir 1 o 2.")
    }
}