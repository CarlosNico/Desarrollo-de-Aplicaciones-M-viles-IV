var opcionIngresada = ""
var saldoTotal: Double = 0.0

func pedirSiONo(_ mensaje: String) -> Bool {
    while true {
        print(mensaje)
        let respuesta = (readLine() ?? "").lowercased()

        if ["si", "s"].contains(respuesta) { return true }
        if ["no", "n"].contains(respuesta) { return false }

        print("\nRespuesta inválida, escribe SI o NO.")
    }
}

func deposito() {
    while true {
        print("\nIngrese la cantidad a depositar:")

        if let entrada = readLine(),
           let cantidad = Double(entrada),
           cantidad > 0 {

            saldoTotal += cantidad
            print("\nSe depositaron \(cantidad) pesos")
            break
        } else {
            print("\nCantidad inválida. Intenta de nuevo.")
        }
    }
}

func retiro() {
    while true {
        print("\nIngrese la cantidad a retirar:")

        if let entrada = readLine(),
           let cantidad = Double(entrada),
           cantidad > 0 {

            if cantidad > saldoTotal {
                print("\nNo tienes suficiente saldo. Tu saldo actual es: \(saldoTotal)")

                return
            } else {
                saldoTotal -= cantidad
                print("\nRetiro exitoso. Retiraste \(cantidad) pesos.")
                break
            }

        } else {
            print("\nCantidad inválida. Intenta de nuevo.")
        }
    }
}

func consultarSaldo() {
    print("\nTu saldo actual es: \(saldoTotal) pesos")
}

while true {

    print("""

----------Banco Mexicano----------

1.- Depositar dinero
2.- Retirar dinero
3.- Consultar saldo
4.- Salir

Ingrese el número de una opción:

""")

    opcionIngresada = readLine() ?? ""

    if opcionIngresada == "4" {
        print("\nGracias por usar el Banco Mexicano. ¡Hasta luego!")
        break
    }

    else if opcionIngresada == "1" {

        repeat {
            deposito()
        } while pedirSiONo("\n¿Deseas realizar otro depósito? (si/no)")

        if !pedirSiONo("\n¿Deseas realizar otra operación? (si/no)") {
            print("\nGracias por usar el Banco Mexicano. ¡Hasta luego!")
            break
        }
    }

    else if opcionIngresada == "2" {

        repeat {
            retiro()
        } while pedirSiONo("\n¿Deseas realizar otro retiro? (si/no)")

        if !pedirSiONo("\n¿Deseas realizar otra operación? (si/no)") {
            print("\nGracias por usar el Banco Mexicano. ¡Hasta luego!")
            break
        }
    }

    else if opcionIngresada == "3" {

        consultarSaldo()

        if !pedirSiONo("\n¿Deseas realizar otra operación? (si/no)") {
            print("\nGracias por usar el Banco Mexicano. ¡Hasta luego!")
            break
        }
    }

    else {
        print("\nOpción inválida")
    }
}