var opcionIngresada = ""
var saldoTotal: Double = 0.0

func pedirSiONo(_ mensaje: String) -> Bool {
    while true {
        print(mensaje)
        let respuesta = (readLine() ?? "").lowercased()

        if ["si", "s"].contains(respuesta) { return true }
        if ["no", "n"].contains(respuesta) { return false }

        print("\nRespuesta inválida, escribe SI o NO.")
    }
}

func deposito() {
    while true {
        print("\nIngrese la cantidad a depositar:")

        if let entrada = readLine(), let cantidad = Double(entrada), cantidad > 0 {
            saldoTotal += cantidad
            print("\nSe depositaron \(cantidad) pesos")
            break
        } else {
            print("\nCantidad inválida. Intenta de nuevo.")
        }
    }
}

while true {

    print("""

----------Banco Mexicano----------
          
1.- Depositar dinero
2.- Retirar dinero
3.- Consultar saldo
4.- Salir

Ingrese el número de una opción:
""")

    opcionIngresada = readLine() ?? ""

    if opcionIngresada == "4" {
        print("\nGracias por usar el Banco Mexicano. ¡Hasta luego!")
        break
    }

    else if opcionIngresada == "1" {

        repeat {
            deposito()
        } while pedirSiONo("\n¿Deseas realizar otro depósito? (si/no)")

        if !pedirSiONo("\n¿Deseas realizar otra operación? (si/no)") {
            print("\nGracias por usar el Banco Mexicano. ¡Hasta luego!")
            break
        }
    }
    else if opcionIngresada == "2" || opcionIngresada == "3" {
        print("\nMódulo no disponible en este momento. Intenta más tarde.")
    }
    else {
        print("\nOpción inválida")
    }
}